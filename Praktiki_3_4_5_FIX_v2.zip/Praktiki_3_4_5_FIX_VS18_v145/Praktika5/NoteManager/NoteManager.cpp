#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#endif

namespace fs = std::filesystem;

struct NoteInfo {
    fs::path path;
    std::string title;
};

void setConsoleUtf8() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
}

fs::path getNotesDirectory() {
#ifdef _WIN32
    const wchar_t* appData = _wgetenv(L"APPDATA");
    if (appData != nullptr) {
        return fs::path(appData) / L"NoteManager" / L"notes";
    }
#else
    const char* dataHome = std::getenv("XDG_DATA_HOME");
    if (dataHome != nullptr && *dataHome != '\0') {
        return fs::path(dataHome) / "NoteManager" / "notes";
    }
    const char* home = std::getenv("HOME");
    if (home != nullptr && *home != '\0') {
        return fs::path(home) / ".local" / "share" / "NoteManager" / "notes";
    }
#endif
    return fs::current_path() / "NoteManagerData" / "notes";
}

std::vector<NoteInfo> getNotes(const fs::path& directory) {
    std::vector<NoteInfo> notes;
    if (!fs::exists(directory)) return notes;

    for (const auto& entry : fs::directory_iterator(directory)) {
        if (!entry.is_regular_file() || entry.path().extension() != ".note") continue;

        std::ifstream input(entry.path(), std::ios::binary);
        std::string title = "Без названия";
        if (input) {
            std::string firstLine;
            if (std::getline(input, firstLine) && !firstLine.empty()) title = firstLine;
        }
        notes.push_back({entry.path(), title});
    }

    std::sort(notes.begin(), notes.end(), [](const NoteInfo& a, const NoteInfo& b) {
        return a.path.filename().string() < b.path.filename().string();
    });
    return notes;
}

bool readInteger(const std::string& prompt, int& result) {
    std::cout << prompt;
    std::string line;
    if (!std::getline(std::cin, line)) return false;
    std::istringstream input(line);
    char extra = '\0';
    if (!(input >> result) || (input >> extra)) {
        std::cout << "Введите целое число.\n";
        return false;
    }
    return true;
}

void printNotes(const std::vector<NoteInfo>& notes) {
    if (notes.empty()) {
        std::cout << "Заметок пока нет.\n";
        return;
    }
    for (std::size_t i = 0; i < notes.size(); ++i) {
        std::cout << (i + 1) << ". " << notes[i].title
                  << " [" << notes[i].path.filename().string() << "]\n";
    }
}

void createNote(const fs::path& directory) {
    std::string title;
    std::cout << "Введите название заметки: ";
    if (!std::getline(std::cin, title) || title.empty()) {
        std::cout << "Название не может быть пустым.\n";
        return;
    }

    std::cout << "Введите текст заметки. Для завершения введите точку на отдельной строке.\n";
    std::string body;
    std::string line;
    while (std::getline(std::cin, line)) {
        if (line == ".") break;
        body += line;
        body += '\n';
    }

    int number = 1;
    fs::path filePath;
    do {
        filePath = directory / ("note_" + std::to_string(number) + ".note");
        ++number;
    } while (fs::exists(filePath));

    std::ofstream output(filePath, std::ios::binary);
    if (!output) {
        std::cout << "Не удалось создать файл заметки.\n";
        return;
    }
    output << title << '\n' << body;
    output.close();
    if (!output) {
        std::cout << "Ошибка при сохранении заметки.\n";
        return;
    }
    std::cout << "Заметка сохранена в файл с расширением .note.\n";
}

void viewNote(const fs::path& directory) {
    const auto notes = getNotes(directory);
    printNotes(notes);
    if (notes.empty()) return;

    int number = 0;
    if (!readInteger("Номер заметки для просмотра: ", number)) return;
    if (number < 1 || static_cast<std::size_t>(number) > notes.size()) {
        std::cout << "Заметки с таким номером нет.\n";
        return;
    }

    std::ifstream input(notes[static_cast<std::size_t>(number - 1)].path, std::ios::binary);
    if (!input) {
        std::cout << "Не удалось открыть заметку.\n";
        return;
    }
    std::cout << "\n--- " << notes[static_cast<std::size_t>(number - 1)].title << " ---\n";
    std::cout << input.rdbuf();
    std::cout << "\n------------------------------\n";
}

void deleteNote(const fs::path& directory) {
    const auto notes = getNotes(directory);
    printNotes(notes);
    if (notes.empty()) return;

    int number = 0;
    if (!readInteger("Номер заметки для удаления: ", number)) return;
    if (number < 1 || static_cast<std::size_t>(number) > notes.size()) {
        std::cout << "Заметки с таким номером нет.\n";
        return;
    }

    std::error_code error;
    const bool removed = fs::remove(notes[static_cast<std::size_t>(number - 1)].path, error);
    if (removed && !error) {
        std::cout << "Заметка удалена.\n";
    } else {
        std::cout << "Не удалось удалить заметку: " << error.message() << '\n';
    }
}

int openNoteFile(const fs::path& filePath) {
    if (!fs::exists(filePath) || !fs::is_regular_file(filePath)) {
        std::cerr << "Файл заметки не найден.\n";
        return 1;
    }
    if (filePath.extension() != ".note") {
        std::cerr << "Поддерживаются только файлы с расширением .note.\n";
        return 1;
    }

    std::ifstream input(filePath, std::ios::binary);
    if (!input) {
        std::cerr << "Не удалось открыть файл заметки.\n";
        return 1;
    }
    std::cout << "Открытие файла: " << filePath.filename().string() << "\n\n";
    std::cout << input.rdbuf();
    return 0;
}

int runApplication() {
    const fs::path notesDirectory = getNotesDirectory();
    std::error_code error;
    fs::create_directories(notesDirectory, error);
    if (error) {
        std::cerr << "Не удалось создать папку для заметок: " << error.message() << '\n';
        return 1;
    }

    std::cout << "Менеджер заметок\n";
    std::cout << "Файлы сохраняются в пользовательской папке данных.\n";

    while (true) {
        std::cout << "\nМеню:\n"
                  << "1. Создать заметку\n"
                  << "2. Просмотреть список заметок\n"
                  << "3. Открыть заметку\n"
                  << "4. Удалить заметку\n"
                  << "0. Выход\n";

        int choice = -1;
        if (!readInteger("Выберите действие: ", choice)) continue;

        try {
            if (choice == 1) {
                createNote(notesDirectory);
            } else if (choice == 2) {
                printNotes(getNotes(notesDirectory));
            } else if (choice == 3) {
                viewNote(notesDirectory);
            } else if (choice == 4) {
                deleteNote(notesDirectory);
            } else if (choice == 0) {
                std::cout << "Завершение работы. Заметки сохранены.\n";
                return 0;
            } else {
                std::cout << "Нет такого пункта меню.\n";
            }
        } catch (const fs::filesystem_error& exception) {
            std::cout << "Ошибка файловой системы: " << exception.what() << '\n';
        }
    }
}

#ifdef _WIN32
int wmain(int argc, wchar_t* argv[]) {
    setConsoleUtf8();
    try {
        if (argc > 1) return openNoteFile(fs::path(argv[1]));
        return runApplication();
    } catch (const fs::filesystem_error& exception) {
        std::cerr << "Ошибка файловой системы: " << exception.what() << '\n';
        return 1;
    }
}
#else
int main(int argc, char* argv[]) {
    setConsoleUtf8();
    try {
        if (argc > 1) return openNoteFile(fs::u8path(argv[1]));
        return runApplication();
    } catch (const fs::filesystem_error& exception) {
        std::cerr << "Ошибка файловой системы: " << exception.what() << '\n';
        return 1;
    }
}
#endif

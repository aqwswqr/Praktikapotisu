#include "TestRunner.h"
#include "Bank.h"

#include <cmath>
#include <iostream>
#include <stdexcept>

void TestRunner::assertTrue(bool condition, const std::string& message) {
    if (condition) {
        ++passed_;
        std::cout << "PASS: " << message << '\n';
    }
    else {
        ++failed_;
        std::cout << "FAIL: " << message << '\n';
    }
}

void TestRunner::assertEqual(double actual, double expected,
                             const std::string& message,
                             double epsilon) {
    assertTrue(std::abs(actual - expected) <= epsilon,
               message + " (expected " + std::to_string(expected) +
               ", got " + std::to_string(actual) + ")");
}

void TestRunner::testCreateAndDeposit() {
    Bank bank;
    const auto id = bank.createAccount("Alice", 100.0);
    bank.deposit(id, 50.0);
    assertEqual(bank.getBalance(id), 150.0,
                "Create account and deposit");
}

void TestRunner::testWithdrawAndTransfer() {
    Bank bank;
    const auto first = bank.createAccount("Bob", 200.0);
    const auto second = bank.createAccount("Carol", 50.0);

    bank.withdraw(first, 70.0);
    bank.transfer(first, second, 50.0);

    assertEqual(bank.getBalance(first), 80.0,
                "Sender balance after transfer");
    assertEqual(bank.getBalance(second), 100.0,
                "Receiver balance after transfer");
}

void TestRunner::testInsufficientFunds() {
    Bank bank;
    const auto id = bank.createAccount("Dave", 30.0);
    bool exceptionCaught = false;

    try {
        bank.withdraw(id, 50.0);
    }
    catch (const InsufficientFunds&) {
        exceptionCaught = true;
    }

    assertTrue(exceptionCaught,
               "Withdrawal without sufficient funds is rejected");
    assertEqual(bank.getBalance(id), 30.0,
                "Balance is unchanged after rejected withdrawal");
}

void TestRunner::testSequenceOfOperations() {
    Bank bank;
    const auto first = bank.createAccount("Eve");
    const auto second = bank.createAccount("Frank");

    bank.deposit(first, 500.0);
    bank.transfer(first, second, 120.0);
    bank.withdraw(second, 20.0);

    assertEqual(bank.getBalance(first), 380.0,
                "First balance after operation sequence");
    assertEqual(bank.getBalance(second), 100.0,
                "Second balance after operation sequence");
}

void TestRunner::testOverdraftScenario() {
    Bank bank;
    const auto id = bank.createAccount("George", 100.0, 50.0);
    bank.withdraw(id, 120.0);

    assertEqual(bank.getBalance(id), -20.0,
                "Overdraft within credit limit");
}

void TestRunner::testTransferRollbackOnFailure() {
    Bank bank;
    const auto first = bank.createAccount("Henry", 200.0);
    const auto second = bank.createAccount("Ivy", 50.0);
    bool exceptionCaught = false;

    try {
        bank.transfer(first, second, 100.0, true);
    }
    catch (const std::runtime_error&) {
        exceptionCaught = true;
    }

    assertTrue(exceptionCaught, "Simulated transfer failure is reported");
    assertEqual(bank.getBalance(first), 200.0,
                "Sender balance restored after failure");
    assertEqual(bank.getBalance(second), 50.0,
                "Receiver balance unchanged after failure");
}

void TestRunner::testTransferTimeoutScenario() {
    Bank bank;
    const bool withinTimeout = bank.externalServiceCall(50, 100);
    const bool afterTimeout = bank.externalServiceCall(120, 100);

    assertTrue(withinTimeout,
               "External service responds within timeout");
    assertTrue(!afterTimeout,
               "External service response exceeds timeout");
}

void TestRunner::run() {
    passed_ = 0;
    failed_ = 0;

    std::cout << "Integration testing: bank system\n\n";

    testCreateAndDeposit();
    testWithdrawAndTransfer();
    testInsufficientFunds();
    testSequenceOfOperations();
    testOverdraftScenario();
    testTransferRollbackOnFailure();
    testTransferTimeoutScenario();

    std::cout << "\nResults: passed = " << passed_
              << ", failed = " << failed_ << '\n';
}

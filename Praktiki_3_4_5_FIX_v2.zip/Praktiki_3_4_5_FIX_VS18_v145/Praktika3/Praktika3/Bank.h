#pragma once

#include "Account.h"
#include "Transaction.h"

#include <mutex>
#include <unordered_map>
#include <vector>
#include <string>

class Bank {
public:
    Bank();

    Account::Id createAccount(
        const std::string& owner,
        double initialBalance = 0.0,
        double creditLimit = 0.0);

    void deposit(Account::Id accountId, double amount);
    void withdraw(Account::Id accountId, double amount);

    void transfer(
        Account::Id fromId,
        Account::Id toId,
        double amount,
        bool simulateFailure = false);

    double getBalance(Account::Id accountId) const;
    std::vector<Transaction> getTransactions() const;
    bool externalServiceCall(int delayMs, int timeoutMs) const;

private:
    mutable std::mutex mutex_;
    std::unordered_map<Account::Id, Account> accounts_;
    std::vector<Transaction> transactions_;
    Account::Id nextId_;
};

#pragma once

#include <string>

struct Transaction {
    int fromAccountId;
    int toAccountId;
    double amount;
    std::string description;
};

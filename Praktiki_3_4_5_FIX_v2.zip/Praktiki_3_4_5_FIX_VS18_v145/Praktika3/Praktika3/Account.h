#pragma once

#include <stdexcept>
#include <string>

class InsufficientFunds : public std::runtime_error {
public:
    explicit InsufficientFunds(const std::string& message)
        : std::runtime_error(message) {}
};

class Account {
public:
    using Id = int;

    Account(Id id, const std::string& owner,
            double initialBalance = 0.0,
            double creditLimit = 0.0);

    Id getId() const;
    const std::string& getOwner() const;
    double getBalance() const;
    double getCreditLimit() const;

    void deposit(double amount);
    void withdraw(double amount);

private:
    Id id_;
    std::string owner_;
    double balance_;
    double creditLimit_;
};

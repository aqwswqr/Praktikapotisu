#pragma once

#include <string>

class TestRunner {
public:
    void run();

private:
    int passed_ = 0;
    int failed_ = 0;

    void assertTrue(bool condition, const std::string& message);
    void assertEqual(double actual, double expected,
                     const std::string& message,
                     double epsilon = 1e-9);

    void testCreateAndDeposit();
    void testWithdrawAndTransfer();
    void testInsufficientFunds();
    void testSequenceOfOperations();
    void testOverdraftScenario();
    void testTransferRollbackOnFailure();
    void testTransferTimeoutScenario();
};

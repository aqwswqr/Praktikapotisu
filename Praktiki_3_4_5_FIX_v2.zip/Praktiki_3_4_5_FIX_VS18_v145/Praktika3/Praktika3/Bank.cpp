#include "Bank.h"

#include <chrono>
#include <stdexcept>
#include <thread>
#include <utility>

Bank::Bank() : nextId_(1) {}

Account::Id Bank::createAccount(
    const std::string& owner,
    double initialBalance,
    double creditLimit) {

    std::lock_guard<std::mutex> lock(mutex_);

    const Account::Id id = nextId_;
    Account account(id, owner, initialBalance, creditLimit);
    accounts_.emplace(id, std::move(account));
    ++nextId_;

    if (initialBalance > 0.0) {
        transactions_.push_back(
            {0, id, initialBalance, "Initial deposit"});
    }

    return id;
}

void Bank::deposit(Account::Id accountId, double amount) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto it = accounts_.find(accountId);
    if (it == accounts_.end()) {
        throw std::invalid_argument("Account not found for deposit");
    }

    it->second.deposit(amount);
    transactions_.push_back({0, accountId, amount, "Deposit"});
}

void Bank::withdraw(Account::Id accountId, double amount) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto it = accounts_.find(accountId);
    if (it == accounts_.end()) {
        throw std::invalid_argument("Account not found for withdrawal");
    }

    it->second.withdraw(amount);
    transactions_.push_back({accountId, 0, amount, "Withdrawal"});
}

void Bank::transfer(
    Account::Id fromId,
    Account::Id toId,
    double amount,
    bool simulateFailure) {

    std::lock_guard<std::mutex> lock(mutex_);

    auto from = accounts_.find(fromId);
    auto to = accounts_.find(toId);

    if (from == accounts_.end() || to == accounts_.end()) {
        throw std::invalid_argument("Account not found for transfer");
    }
    if (fromId == toId) {
        throw std::invalid_argument("Cannot transfer to the same account");
    }

    from->second.withdraw(amount);

    if (simulateFailure) {
        from->second.deposit(amount);
        throw std::runtime_error("Simulated transfer failure");
    }

    try {
        to->second.deposit(amount);
    }
    catch (...) {
        from->second.deposit(amount);
        throw;
    }

    transactions_.push_back({fromId, toId, amount, "Transfer"});
}

double Bank::getBalance(Account::Id accountId) const {
    std::lock_guard<std::mutex> lock(mutex_);

    auto it = accounts_.find(accountId);
    if (it == accounts_.end()) {
        throw std::invalid_argument("Account not found for balance request");
    }

    return it->second.getBalance();
}

std::vector<Transaction> Bank::getTransactions() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return transactions_;
}

bool Bank::externalServiceCall(int delayMs, int timeoutMs) const {
    if (delayMs < 0 || timeoutMs < 0) {
        throw std::invalid_argument("Delay and timeout cannot be negative");
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(delayMs));
    return delayMs <= timeoutMs;
}

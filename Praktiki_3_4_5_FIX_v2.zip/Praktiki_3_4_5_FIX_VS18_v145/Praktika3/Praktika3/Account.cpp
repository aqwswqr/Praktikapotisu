#include "Account.h"

Account::Account(Id id, const std::string& owner,
                 double initialBalance, double creditLimit)
    : id_(id),
      owner_(owner),
      balance_(initialBalance),
      creditLimit_(creditLimit) {
    if (owner.empty()) {
        throw std::invalid_argument("Account owner cannot be empty");
    }

    if (initialBalance < 0.0) {
        throw std::invalid_argument("Initial balance cannot be negative");
    }

    if (creditLimit < 0.0) {
        throw std::invalid_argument("Credit limit cannot be negative");
    }
}

Account::Id Account::getId() const {
    return id_;
}

const std::string& Account::getOwner() const {
    return owner_;
}

double Account::getBalance() const {
    return balance_;
}

double Account::getCreditLimit() const {
    return creditLimit_;
}

void Account::deposit(double amount) {
    if (amount <= 0.0) {
        throw std::invalid_argument(
            "Deposit amount must be greater than zero");
    }

    balance_ += amount;
}

void Account::withdraw(double amount) {
    if (amount <= 0.0) {
        throw std::invalid_argument(
            "Withdrawal amount must be greater than zero");
    }

    if (amount > balance_ + creditLimit_) {
        throw InsufficientFunds(
            "Insufficient funds, including credit limit");
    }

    balance_ -= amount;
}

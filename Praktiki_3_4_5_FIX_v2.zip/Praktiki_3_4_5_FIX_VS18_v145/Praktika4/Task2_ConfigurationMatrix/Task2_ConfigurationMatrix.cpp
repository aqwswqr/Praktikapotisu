#include <algorithm>
#include <functional>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
#include <utility>
#ifdef _WIN32
#include <windows.h>
#endif

struct Category {
    std::string name;
    std::vector<std::string> options;
};

std::string csvEscape(const std::string& value) {
    if (value.find_first_of(",\"\n\r") == std::string::npos) {
        return value;
    }
    std::string escaped = "\"";
    for (char ch : value) {
        if (ch == '\"') escaped += "\"\"";
        else escaped += ch;
    }
    escaped += '\"';
    return escaped;
}

int readInt(const std::string& prompt, int minimum, int maximum) {
    while (true) {
        std::cout << prompt;
        int value{};
        if (std::cin >> value && value >= minimum && value <= maximum) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
        std::cout << "Введите целое число от " << minimum << " до " << maximum << ".\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

std::string readLine(const std::string& prompt) {
    std::string value;
    do {
        std::cout << prompt;
        std::getline(std::cin, value);
        if (value.empty()) std::cout << "Значение не должно быть пустым.\n";
    } while (value.empty());
    return value;
}

int main() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    std::cout << "Генератор матрицы конфигурационного тестирования\n\n";
    const int categoryCount = readInt("Количество категорий (1-8): ", 1, 8);
    std::vector<Category> categories;
    categories.reserve(static_cast<std::size_t>(categoryCount));

    std::size_t totalCombinations = 1;
    for (int i = 0; i < categoryCount; ++i) {
        Category category;
        category.name = readLine("Название категории " + std::to_string(i + 1) + ": ");
        const int optionCount = readInt("Количество вариантов для категории (1-10): ", 1, 10);
        for (int j = 0; j < optionCount; ++j) {
            category.options.push_back(readLine("  Вариант " + std::to_string(j + 1) + ": "));
        }
        totalCombinations *= category.options.size();
        if (totalCombinations > 5000) {
            std::cout << "Слишком много комбинаций (более 5000). Уменьшите число вариантов.\n";
            return 1;
        }
        categories.push_back(std::move(category));
    }

    std::vector<std::vector<std::string>> combinations;
    std::vector<std::string> current;
    std::function<void(std::size_t)> generate = [&](std::size_t index) {
        if (index == categories.size()) {
            combinations.push_back(current);
            return;
        }
        for (const auto& option : categories[index].options) {
            current.push_back(option);
            generate(index + 1);
            current.pop_back();
        }
    };
    generate(0);

    std::vector<int> priorities(combinations.size(), 1);
    std::cout << "\nСгенерировано комбинаций: " << combinations.size() << '\n';
    const int overrides = readInt(
        "Сколько комбинаций отметить собственным приоритетом (0-" +
        std::to_string(combinations.size()) + "): ",
        0, static_cast<int>(combinations.size()));

    for (int i = 0; i < overrides; ++i) {
        std::cout << "\nКомбинации нумеруются с 1.\n";
        const int row = readInt("Номер комбинации: ", 1, static_cast<int>(combinations.size()));
        const int priority = readInt("Приоритет (1-низкий, 2-средний, 3-высокий): ", 1, 3);
        priorities[static_cast<std::size_t>(row - 1)] = priority;
    }

    std::ostringstream csv;
    for (const auto& category : categories) csv << csvEscape(category.name) << ',';
    csv << "Priority\n";
    for (std::size_t i = 0; i < combinations.size(); ++i) {
        for (const auto& option : combinations[i]) csv << csvEscape(option) << ',';
        csv << priorities[i] << '\n';
    }

    std::cout << "\nМатрица покрытия в формате CSV:\n" << csv.str();
    std::cout << "\nПри необходимости скопируйте таблицу в файл coverage.csv.\n";
    return 0;
}

#include <windows.h>
#include <psapi.h>
#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>

#pragma comment(lib, "Psapi.lib")

const char* getArchitecture(WORD architecture) {
    switch (architecture) {
    case PROCESSOR_ARCHITECTURE_AMD64: return "x64 (AMD64)";
    case PROCESSOR_ARCHITECTURE_INTEL: return "x86 (Intel)";
    case PROCESSOR_ARCHITECTURE_ARM64: return "ARM64";
    case PROCESSOR_ARCHITECTURE_ARM: return "ARM";
    default: return "Неизвестная архитектура";
    }
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    SYSTEM_INFO systemInfo{};
    GetNativeSystemInfo(&systemInfo);

    std::cout << "Сбор характеристик персонального компьютера\n\n";
    std::cout << "Архитектура процессора: "
              << getArchitecture(systemInfo.wProcessorArchitecture) << '\n';
    std::cout << "Логических процессоров: " << systemInfo.dwNumberOfProcessors << '\n';
    std::cout << "Размер страницы памяти: " << systemInfo.dwPageSize << " байт\n";

    MEMORYSTATUSEX memoryStatus{};
    memoryStatus.dwLength = static_cast<DWORD>(sizeof(memoryStatus));
    if (GlobalMemoryStatusEx(&memoryStatus)) {
        const double totalRam = static_cast<double>(memoryStatus.ullTotalPhys) / (1024.0 * 1024.0 * 1024.0);
        const double availableRam = static_cast<double>(memoryStatus.ullAvailPhys) / (1024.0 * 1024.0 * 1024.0);
        std::cout << std::fixed << std::setprecision(2);
        std::cout << "Оперативная память всего: " << totalRam << " ГБ\n";
        std::cout << "Оперативная память свободна: " << availableRam << " ГБ\n";
        std::cout << "Загрузка физической памяти: " << memoryStatus.dwMemoryLoad << "%\n";
    } else {
        std::cout << "Не удалось получить сведения об оперативной памяти.\n";
    }

    ULARGE_INTEGER freeBytesAvailable{}, totalBytes{}, totalFreeBytes{};
    if (GetDiskFreeSpaceExW(L"C:\\", &freeBytesAvailable, &totalBytes, &totalFreeBytes)) {
        const double totalGb = static_cast<double>(totalBytes.QuadPart) / (1024.0 * 1024.0 * 1024.0);
        const double freeGb = static_cast<double>(totalFreeBytes.QuadPart) / (1024.0 * 1024.0 * 1024.0);
        std::cout << "Диск C: всего: " << totalGb << " ГБ\n";
        std::cout << "Диск C: свободно: " << freeGb << " ГБ\n";
    } else {
        std::cout << "Не удалось получить сведения о диске C:.\n";
    }

    PROCESS_MEMORY_COUNTERS_EX processMemory{};
    processMemory.cb = static_cast<DWORD>(sizeof(processMemory));
    if (GetProcessMemoryInfo(GetCurrentProcess(),
        reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&processMemory),
        static_cast<DWORD>(sizeof(processMemory)))) {
        const double workingSetMb = static_cast<double>(processMemory.WorkingSetSize) / (1024.0 * 1024.0);
        const double privateMb = static_cast<double>(processMemory.PrivateUsage) / (1024.0 * 1024.0);
        std::cout << "Память, используемая программой: " << workingSetMb << " МБ\n";
        std::cout << "Частная память процесса: " << privateMb << " МБ\n";
    } else {
        std::cout << "Не удалось получить сведения о памяти процесса.\n";
    }

    volatile std::uint64_t checksum = 0;
    const auto start = std::chrono::steady_clock::now();
    for (std::uint64_t i = 0; i < 5000000ULL; ++i) {
        checksum = checksum + i;
    }
    const auto finish = std::chrono::steady_clock::now();
    const auto elapsedMs = std::chrono::duration<double, std::milli>(finish - start).count();

    std::cout << "Время выполнения тестового вычисления: "
              << elapsedMs << " мс\n";
    std::cout << "Контрольная сумма: " << checksum << '\n';
    std::cout << "\nСбор характеристик завершён.\n";
    return 0;
}

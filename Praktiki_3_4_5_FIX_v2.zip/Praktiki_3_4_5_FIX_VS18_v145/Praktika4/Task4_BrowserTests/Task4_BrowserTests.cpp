#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#endif

class BrowserTestRunner {
public:
    void addBrowser(const std::string& browserName) {
        browsers_.push_back(browserName);
    }

    void addTestScript(const std::string& script) {
        scripts_.push_back(script);
    }

    void runTests() {
        std::vector<std::string> browserReports(browsers_.size());
        std::vector<std::thread> threads;
        threads.reserve(browsers_.size());

        for (std::size_t i = 0; i < browsers_.size(); ++i) {
            threads.emplace_back([this, i, &browserReports]() {
                std::ostringstream local;
                local << "=== Браузер: " << browsers_[i] << " ===\n";
                for (const auto& script : scripts_) {
                    local << "[PASS, имитация] " << script << '\n';
                }
                local << "Тестирование " << browsers_[i] << " завершено.\n";
                browserReports[i] = local.str();
            });
        }

        for (auto& thread : threads) {
            if (thread.joinable()) thread.join();
        }

        report_.clear();
        for (const auto& browserReport : browserReports) {
            report_ += browserReport + "\n";
        }
        std::cout << report_;
    }

    std::string getReport() const {
        return report_;
    }

private:
    std::vector<std::string> browsers_;
    std::vector<std::string> scripts_;
    std::string report_;
};

int main() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    BrowserTestRunner runner;
    runner.addBrowser("Chrome");
    runner.addBrowser("Firefox");
    runner.addBrowser("Edge");

    runner.addTestScript("Открытие главной страницы");
    runner.addTestScript("Проверка поиска");
    runner.addTestScript("Проверка формы авторизации");

    runner.runTests();
    std::cout << "Отчёт сформирован для всех браузеров.\n";
    return 0;
}

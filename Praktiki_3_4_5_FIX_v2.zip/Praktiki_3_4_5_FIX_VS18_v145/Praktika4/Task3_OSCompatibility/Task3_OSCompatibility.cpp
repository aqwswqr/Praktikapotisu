#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <utility>
#ifdef _WIN32
#include <windows.h>
#endif

class OperatingSystem {
public:
    virtual bool checkDependencies() const = 0;
    virtual std::string getName() const = 0;
    virtual std::string getResult() const = 0;
    virtual ~OperatingSystem() = default;
};

class WindowsOS : public OperatingSystem {
public:
    WindowsOS(int version, bool is64Bit, bool dependencies)
        : version_(version), is64Bit_(is64Bit), dependencies_(dependencies) {}

    bool checkDependencies() const override {
        return version_ >= 10 && is64Bit_ && dependencies_;
    }

    std::string getName() const override {
        return "Windows " + std::to_string(version_) +
            (is64Bit_ ? " (64-bit)" : " (32-bit)");
    }

    std::string getResult() const override {
        if (checkDependencies()) return "Совместимо: требования выполнены.";
        return "Несовместимо: проверьте версию ОС, разрядность и библиотеки.";
    }

private:
    int version_;
    bool is64Bit_;
    bool dependencies_;
};

class LinuxOS : public OperatingSystem {
public:
    LinuxOS(std::string kernelVersion, int majorVersion, bool is64Bit, bool dependencies)
        : kernelVersion_(std::move(kernelVersion)), majorVersion_(majorVersion),
          is64Bit_(is64Bit), dependencies_(dependencies) {}

    bool checkDependencies() const override {
        return majorVersion_ >= 5 && is64Bit_ && dependencies_;
    }

    std::string getName() const override {
        return "Linux kernel " + kernelVersion_ +
            (is64Bit_ ? " (64-bit)" : " (32-bit)");
    }

    std::string getResult() const override {
        if (checkDependencies()) return "Совместимо: требования выполнены.";
        return "Несовместимо: проверьте версию ядра, разрядность и библиотеки.";
    }

private:
    std::string kernelVersion_;
    int majorVersion_;
    bool is64Bit_;
    bool dependencies_;
};

class MacOS : public OperatingSystem {
public:
    MacOS(int version, bool is64Bit, bool dependencies)
        : version_(version), is64Bit_(is64Bit), dependencies_(dependencies) {}

    bool checkDependencies() const override {
        return version_ >= 13 && is64Bit_ && dependencies_;
    }

    std::string getName() const override {
        return "macOS " + std::to_string(version_) +
            (is64Bit_ ? " (64-bit)" : " (32-bit)");
    }

    std::string getResult() const override {
        if (checkDependencies()) return "Совместимо: требования выполнены.";
        return "Несовместимо: проверьте версию ОС и наличие библиотек.";
    }

private:
    int version_;
    bool is64Bit_;
    bool dependencies_;
};

int main() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    std::ofstream logFile("compatibility_report.log");
    if (!logFile) {
        std::cerr << "Не удалось создать файл compatibility_report.log.\n";
        return 1;
    }

    std::vector<std::unique_ptr<OperatingSystem>> systems;
    systems.push_back(std::make_unique<WindowsOS>(11, true, true));
    systems.push_back(std::make_unique<WindowsOS>(7, false, true));
    systems.push_back(std::make_unique<LinuxOS>("6.8", 6, true, true));
    systems.push_back(std::make_unique<LinuxOS>("4.19", 4, true, true));
    systems.push_back(std::make_unique<MacOS>(14, true, true));
    systems.push_back(std::make_unique<MacOS>(12, true, false));

    std::cout << "Имитация проверки совместимости приложения\n\n";
    for (const auto& system : systems) {
        const std::string line = system->getName() + "\n" + system->getResult() + "\n---\n";
        std::cout << line;
        logFile << line;
    }

    logFile.close();
    std::cout << "Отчёт сохранён в compatibility_report.log.\n";
    return 0;
}

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <atomic>
#include <algorithm>
#include <chrono>
#include <condition_variable>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

struct ResourceSample {
    double cpuPercent = 0.0;
    double ramPercent = 0.0;
    double diskPercent = 0.0;
};

unsigned long long fileTimeValue(const FILETIME& value) {
    ULARGE_INTEGER result{};
    result.LowPart = value.dwLowDateTime;
    result.HighPart = value.dwHighDateTime;
    return result.QuadPart;
}

class ResourceMonitor {
public:
    explicit ResourceMonitor(int intervalSeconds)
        : intervalSec_(intervalSeconds), running_(false) {}

    ~ResourceMonitor() {
        stopMonitoring();
    }

    void startMonitoring() {
        if (intervalSec_ < 1 || intervalSec_ > 60) {
            throw std::invalid_argument("Интервал должен быть от 1 до 60 секунд.");
        }
        bool expected = false;
        if (!running_.compare_exchange_strong(expected, true)) return;
        {
            std::lock_guard<std::mutex> lock(samplesMutex_);
            samples_.clear();
        }
        monitorThread_ = std::thread(&ResourceMonitor::monitorLoop, this);
    }

    void stopMonitoring() {
        running_ = false;
        stopCondition_.notify_all();
        if (monitorThread_.joinable()) monitorThread_.join();
    }

    std::string generateLoadGraph() const {
        const auto samples = getSamples();
        std::ostringstream output;
        output << "Текстовый график (один символ примерно соответствует 5%)\n";
        if (samples.empty()) {
            output << "Нет данных для построения графика.\n";
            return output.str();
        }

        for (std::size_t i = 0; i < samples.size(); ++i) {
            output << "Замер " << (i + 1)
                   << " | CPU  " << makeBar(samples[i].cpuPercent)
                   << " " << std::fixed << std::setprecision(1) << samples[i].cpuPercent << "%\n";
            output << "        | RAM  " << makeBar(samples[i].ramPercent)
                   << " " << samples[i].ramPercent << "%\n";
            output << "        | Диск " << makeBar(samples[i].diskPercent)
                   << " " << samples[i].diskPercent << "%\n";
        }
        return output.str();
    }

    double getAvgCPULoad() const {
        const auto samples = getSamples();
        if (samples.empty()) return 0.0;
        double total = 0.0;
        for (const auto& sample : samples) total += sample.cpuPercent;
        return total / static_cast<double>(samples.size());
    }

    double getPeakCPULoad() const {
        const auto samples = getSamples();
        double peak = 0.0;
        for (const auto& sample : samples) peak = std::max(peak, sample.cpuPercent);
        return peak;
    }

    double getPeakRAMLoad() const {
        const auto samples = getSamples();
        double peak = 0.0;
        for (const auto& sample : samples) peak = std::max(peak, sample.ramPercent);
        return peak;
    }

    double getPeakDiskLoad() const {
        const auto samples = getSamples();
        double peak = 0.0;
        for (const auto& sample : samples) peak = std::max(peak, sample.diskPercent);
        return peak;
    }

    std::size_t getSampleCount() const {
        std::lock_guard<std::mutex> lock(samplesMutex_);
        return samples_.size();
    }

private:
    int intervalSec_;
    std::atomic<bool> running_;
    std::thread monitorThread_;
    mutable std::mutex samplesMutex_;
    std::vector<ResourceSample> samples_;
    std::mutex waitMutex_;
    std::condition_variable stopCondition_;

    std::vector<ResourceSample> getSamples() const {
        std::lock_guard<std::mutex> lock(samplesMutex_);
        return samples_;
    }

    static std::string makeBar(double value) {
        const int length = std::clamp(static_cast<int>(value / 5.0), 0, 20);
        return std::string(static_cast<std::size_t>(length), '#');
    }

    static double readCpuUsage(
        FILETIME& previousIdle,
        FILETIME& previousKernel,
        FILETIME& previousUser,
        bool& hasPrevious) {

        FILETIME idle{}, kernel{}, user{};
        if (!GetSystemTimes(&idle, &kernel, &user)) return 0.0;

        if (!hasPrevious) {
            previousIdle = idle;
            previousKernel = kernel;
            previousUser = user;
            hasPrevious = true;
            return 0.0;
        }

        const auto idleNow = fileTimeValue(idle);
        const auto kernelNow = fileTimeValue(kernel);
        const auto userNow = fileTimeValue(user);
        const auto idleBefore = fileTimeValue(previousIdle);
        const auto kernelBefore = fileTimeValue(previousKernel);
        const auto userBefore = fileTimeValue(previousUser);

        previousIdle = idle;
        previousKernel = kernel;
        previousUser = user;

        const unsigned long long idleDelta = idleNow - idleBefore;
        const unsigned long long kernelDelta = kernelNow - kernelBefore;
        const unsigned long long userDelta = userNow - userBefore;
        const unsigned long long totalDelta = kernelDelta + userDelta;
        if (totalDelta == 0 || idleDelta > totalDelta) return 0.0;

        const double busy = static_cast<double>(totalDelta - idleDelta);
        return std::clamp(100.0 * busy / static_cast<double>(totalDelta), 0.0, 100.0);
    }

    static double readRamUsage() {
        MEMORYSTATUSEX status{};
        status.dwLength = sizeof(status);
        if (!GlobalMemoryStatusEx(&status)) return 0.0;
        return static_cast<double>(status.dwMemoryLoad);
    }

    static double readDiskUsage() {
        ULARGE_INTEGER available{}, total{}, totalFree{};
        if (!GetDiskFreeSpaceExW(L"C:\\", &available, &total, &totalFree) || total.QuadPart == 0) {
            return 0.0;
        }
        const double used = static_cast<double>(total.QuadPart - totalFree.QuadPart);
        return std::clamp(100.0 * used / static_cast<double>(total.QuadPart), 0.0, 100.0);
    }

    void monitorLoop() {
        FILETIME previousIdle{}, previousKernel{}, previousUser{};
        bool hasPrevious = false;

        while (running_) {
            ResourceSample sample;
            sample.cpuPercent = readCpuUsage(
                previousIdle, previousKernel, previousUser, hasPrevious);
            sample.ramPercent = readRamUsage();
            sample.diskPercent = readDiskUsage();

            {
                std::lock_guard<std::mutex> lock(samplesMutex_);
                samples_.push_back(sample);
            }

            std::unique_lock<std::mutex> lock(waitMutex_);
            stopCondition_.wait_for(
                lock,
                std::chrono::seconds(intervalSec_),
                [this]() { return !running_.load(); });
        }
    }
};

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    int interval = 1;
    int duration = 8;
    std::cout << "Монитор ресурсов системы\n";
    std::cout << "Введите интервал замера в секундах (1-60): ";
    if (!(std::cin >> interval) || interval < 1 || interval > 60) {
        std::cerr << "Некорректный интервал. Используйте число от 1 до 60.\n";
        return 1;
    }
    std::cout << "Введите длительность мониторинга в секундах (5-300): ";
    if (!(std::cin >> duration) || duration < 5 || duration > 300) {
        std::cerr << "Некорректная длительность. Используйте число от 5 до 300.\n";
        return 1;
    }

    ResourceMonitor monitor(interval);
    monitor.startMonitoring();
    for (int second = 1; second <= duration; ++second) {
        std::cout << "Выполняется имитация тестирования: "
                  << second << "/" << duration << " сек.\n";
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    monitor.stopMonitoring();

    std::cout << "\nКоличество замеров: " << monitor.getSampleCount() << '\n';
    std::cout << monitor.generateLoadGraph();
    std::cout << std::fixed << std::setprecision(1);
    std::cout << "Средняя загрузка CPU: " << monitor.getAvgCPULoad() << "%\n";
    std::cout << "Пиковая загрузка CPU: " << monitor.getPeakCPULoad() << "%\n";
    std::cout << "Пиковая загрузка RAM: " << monitor.getPeakRAMLoad() << "%\n";
    std::cout << "Занято места на диске C: (максимум среди замеров): "
              << monitor.getPeakDiskLoad() << "%\n";
    return 0;
}
